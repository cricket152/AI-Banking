# 模拟银行业务契约

本文说明 T05–T11 的后端实现。所有金额都是虚构的整数分，币种仅支持 CNY；只支持本地模拟银行内已登记账户之间的转账，费用固定为 0。没有真实银行、支付渠道、定时扣款或退款接口。

当前 Agent 有五个查询工具及转账准备、取消订阅准备和操作查询工具。默认准备待人工确认操作；用户在当前对话显式选定预授权后，由应用在授权范围内复核执行。模型没有创建授权、批准、直接执行或对账工具。前端已提供业务表单、独立确认弹窗、授权管理与操作状态；对话绑定及使用步骤见 [Agent 受控操作](agent-operations.md)。本地测试通过不等于真实模型、竞赛全流程或生产安全验收通过。

## 安装与既有数据库升级

新建空数据库会随正常初始化建立银行表。已有数据库不在启动时自动升级：旧账户查询和对话仍可使用，新业务返回 `BANK_SETUP_REQUIRED`（503）。升级前停止本地服务，核实 `.env` 的 `BANK_DATABASE` 指向正确文件，再执行：

```powershell
.\.venv\Scripts\python.exe -m ai_banking.banking.cli upgrade
```

命令打印目标与影响，输入 `yes` 后先用 SQLite backup API 保存完整备份，再在事务内新增 9 张银行表、索引和虚构登记数据。备份位于数据库同目录，名称含 `before-bank-`；既有用户、密码、会话、账户余额、流水和聊天不被覆盖。重复升级不重建数据。事务失败回滚新增内容并保留备份，不自动恢复或删除文件。`--yes` 仅供已明确批准的升级使用，不代表免除确认要求。

新增表：`bank_meta`、`bank_payees`、`bank_grants`、`bank_tasks`、`bank_subscriptions`、`bank_operations`、`bank_ledger`、`bank_challenges`、`bank_events`。每个用户新增自己的两个账户收款项和两份虚构登记订阅；没有自动预授权。

## 身份与接口边界

接口统一以 `/api/bank` 开头。所有接口要求有效会话；POST 还要求同源、JSON 和有效 CSRF，未知请求字段被拒绝。身份来自服务端，不接受客户端指定的 `user_id`。注册收款人和创建预授权还必须重新验证密码，失败会限流。密码、Cookie、CSRF、确认挑战不能进入 Agent 上下文或日志。

账户、任务、操作、授权、订阅和审计按所有者隔离，越权和不存在统一返回 404。用户可以主动登记已知的其他模拟账户作为收款账户，但不能因此查询对方余额或操作记录。收款只在真实发生本地转账的同一事务内入账，没有“声明已收款”接口。

## 任务、幂等与记账

1. 客户端生成一次性的 UUID `request_id` 创建任务，保留返回的任务 ID。
2. 每个逻辑步骤使用稳定的 `step_key` 准备操作。`(task_id, step_key)` 唯一：相同参数返回原操作，参数变化返回 `STEP_PARAMETERS_CONFLICT`。一个任务最多 100 个步骤。
3. 服务端生成操作 ID、业务幂等键、参数摘要与授权依据。重复确认或执行同一操作只返回原结果，不重复扣款。
4. 执行器在事务中复核会话、操作状态、余额、授权和预占；借方与贷方流水、账户余额、双边账本、额度和成功状态一起提交。借贷金额相反且绝对值相等。

新建任务和新建步骤表示新业务请求；幂等不会自动判断不同任务是否语义相同。Agent 按当前对话派生稳定任务请求编号、按业务参数派生步骤，并兼容旧 `primary_intent`；模型不能提供这些字段。相同参数始终复用原操作，只有已有步骤全部成功才可新增下一步。跨轮和重启不重新付款；新建对话表示新业务，不能用于自动重试旧操作。

## 人工审批

准备时选择 `HUMAN_APPROVAL`，进入 `awaiting_confirmation`，不改余额、不自动执行。默认确认期限 300 秒，接口允许 30–3600 秒；这是项目配置范围，不是比赛规则。

应用获取 `challenge` 时返回后端生成的不可变操作摘要。决定请求必须带当前会话绑定的挑战、原 `parameters_digest`，并明确选择 `approve` 或 `reject`。模型文本、`confirmed=true`、模糊答复均不能代替确认。金额或收款人改变需要新操作和新确认。

一直未回复：超时后不执行，后续查询或操作时标记 `expired`。模糊回复：接口拒绝，保持等待。拒绝：标记 `rejected`。明确批准：复核后执行；重复批准读取原结果。确认凭证不跨会话复用。

## 预先授权

按用户确认的规则，每次开启必须重新输入登录密码，并显式提供：

- 付款账户、CNY、允许收款账户；
- 累计上限 `limit_minor`、单笔上限 `single_minor`、最低保留余额 `minimum_minor`；
- 绝对过期时间 `expires_at`（UTC Unix 秒）；
- 允许的操作种类 `transfer` / `cancel_subscription`，以及取消所针对的订阅 ID；
- 防重复创建的 UUID `request_id`。

没有默认授权。有效期必须在未来，单笔不得大于累计；转账授权的上限必须为正。只允许取消指定订阅的授权可以采用零资金预算。相同请求、相同策略返回原授权；相同请求改变策略返回冲突。同一付款账户、同一身份版本不能静默叠加多个有效授权，变更前需明确撤销旧授权。

剩余额度 = 累计上限 − 成功支出 − 尚未释放的预占。准备预授权操作时原子预占，成功时转为支出；收入、内部收款和退款不补回额度。同一授权跨聊天、退出再登录和服务重启持续累计，不自动重置周期。账户可用余额还需扣除其他操作预占，并满足最低保留余额。

撤销或过期阻止未提交操作；待处理操作释放预占，已完成操作不回滚，结果未知仍保留预占。密码重置 / 用户停用会撤销会话，身份版本变化使旧授权失效；普通退出不撤销持久授权，但没有有效登录会话不能发起或执行操作。本版不支持无人登录的后台执行。

## 状态、恢复与审计

```text
人工：awaiting_confirmation -> authorized -> executing -> succeeded
预授权：authorized -> executing -> succeeded
待处理：-> rejected / expired
执行：-> failed / outcome_unknown
结果未知：原编号对账 -> failed，或继续等待人工核查
```

启动发现遗留 `executing` 时改为 `outcome_unknown`，不自动重发。执行中异常也进入未知状态并保留预占；未知操作阻止同一付款账户和授权继续新增资金操作。恢复接口先读原操作，不凭聊天摘要推断成功。

本地 SQLite 事务若已提交，账本与成功状态同时存在；响应丢失时查询会得到 `succeeded`。未知操作经对账确认没有账本，且账户余额与期初加全量流水一致时，标记明确未执行并释放预占；发现账本矛盾或余额不一致则返回 `RECONCILIATION_REQUIRES_REVIEW`，不猜测修复。这一保证限于本地原子事务，不能直接推广至外部支付渠道。

`GET /api/accounts` 在同一事务读取账户与快照，包含递增事件版本、UTC 时间、成功支出、预占、有效授权和操作状态计数。兼容字段 `funds_mode=READ_ONLY` 与 `agent_funds_access=false` 表示模型无直接执行权限，`banking_mode` 描述后端授权情况；对话实际策略另由 `execution_policy` 提供。快照不是新的权限凭证。任务查询返回已保存的步骤与操作编号；事件接口按单调序号分页，不含密码或确认凭据。对话策略和暂停复用原事件表持久化，未新增表。

## 账单和订阅口径

- 日期采用 `Asia/Shanghai` 自然日，`start` 包含、`end` 不包含，单次最多 366 天。Windows 安装轻量 `tzdata` 提供 IANA 时区规则。
- 汇总使用指定日期内的全量流水，不能拿最近 30 条代替月报；按类别、商户、月份统计，返回依据流水 ID。
- 消费与转账分开，收入与退款分开；净消费 = 消费 − 退款，订阅消费单列。单笔非转账支出不少于 1000 元只是公开的项目演示启发式提示，不是欺诈判断或比赛规定。
- 订阅是明确标记的虚构登记记录；没有实现从流水自动推断，`inferred_candidates=[]`。查询时标记未来 7 天的续费提醒，没有后台推送或扣款。
- 取消订阅复用上述两种授权和操作查询，立即停止模拟登记状态；重复取消不重复产生效果。取消未来续费不等于现在退款或增加可用余额，不提供自动恢复订阅。

## API 速查

下表省略公共前缀 `/api/bank`。金额字段均为严格整数分，拒绝布尔值和浮点数。`{}` 表示严格空对象；完整请求字段以 `src/ai_banking/banking/api.py` 的 Pydantic 模型为准。应用未开放 Swagger / OpenAPI 网页端点。

| 请求 | 用途 / 主要输入 |
| --- | --- |
| `GET /payees` | 本人登记收款人，不返回对方余额 |
| `POST /payees` | `name`、`account_id`、`password` |
| `POST /payees/demo` | 密码再认证后显式载入本人独立虚构联系人；幂等，不扣款 |
| `POST /payees/{id}/note` | `note`、`password`；只改本人的备注，不改账户绑定 |
| `POST /plans/preview` | 账户、收款人、金额及 1–5 项登记订阅；只生成可核对方案与影响 |
| `POST /plans` | 上述字段及 `request_id`、`evidence_digest`、`acknowledged=true`；保存新应用对话与计划，不授权或执行 |
| `POST /tasks` | UUID `request_id`，返回稳定任务 ID |
| `GET /tasks/{id}` | 检查点、步骤与原操作编号 |
| `GET /grants` | 策略、累计支出、预占与剩余额度 |
| `POST /grants` | 上文完整预授权字段与 `password` |
| `POST /grants/{id}/revoke` | `{}`，撤销尚未提交的授权 |
| `POST /transfers/prepare` | `task_id`、`step_key`、`source_id`、`payee_id`、`amount_minor`、`currency`、`mode`，预授权另需 `grant_id` |
| `POST /subscriptions/cancel/prepare` | 同上，不含收款人和金额，改为 `subscription_id` |
| `GET /operations/{id}` | 持久化操作及结果 |
| `GET /operations?limit=50&task_id=...` | 本人操作列表，最多 100 条；可选任务归属校验 |
| `POST /operations/{id}/challenge` | `{}`，得到会话绑定挑战和准确摘要 |
| `POST /operations/{id}/decision` | `decision`、`challenge`、`parameters_digest`；明确批准后执行 |
| `POST /operations/{id}/execute` | `{}`；只有已获合法授权的操作才可执行 |
| `POST /operations/{id}/reconcile` | `{}`；按原操作核对未知结果，不重试付款 |
| `GET /events?after=0&limit=50` | 本人事件，`next_after` 用于继续查询，最多 100 条 |
| `GET /reports?start=2026-01-01&end=2027-01-01` | 闭开日期区间账单，示例日期不代表比赛赛程 |
| `GET /subscriptions` | 登记订阅、状态与查询时计算的续费提醒 |
| `GET /reports/entries?start=...&end=...&offset=0&limit=20` | 本人区间流水依据，支持分类与流水 ID 筛选，最多 50 条 / 页 |
| `POST /subscriptions/candidates/{id}/confirm` | `evidence_digest`、`acknowledged=true`；核验周期证据后显式登记，不扣款或授权 |

账单新增前一等长区间对比、分类增减与历史中位数异常线索；订阅查询新增带流水证据的疑似候选。规则、日期口径和确认流程见 [账单洞察](billing-insights.md)。

主要错误：401 会话 / 再认证失败；403 CSRF、确认凭证或策略范围不符；404 不存在或越权；409 重复请求参数冲突、额度 / 余额不足、状态不允许；422 输入不合法；503 数据库需升级或提交后回执暂不可用。后者应先查原操作，不换编号重试。

## 验证与剩余工作

联系人元数据与固定跨场景计划复用原事件表。转账确认摘要追加后端生成的收款人名称、备注、银行 / 尾号和余额预览；不公开对方余额。原 `Bank.prepare` 同时约束计划内的顺序、对象、金额与幂等编号。规则和边界见 [收款人与转账方案](transfer-workflows.md)。

相关测试位于 `tests/test_banking.py`、`tests/test_banking_edges.py`，覆盖并发、回滚、响应丢失、重启、确认、预算、隔离、日期和升级。执行命令见 [本地开发](local-development.md)，实际结果见 [项目状态](../PROJECT_STATUS.md)。

资金 UI、Agent 多步骤及受控预授权执行已经实现，追加覆盖见 `tests/test_agent_workflow.py`。后续工作是新闭环的真实模型验收、队友审查、T15 精确上下文预算与摘要，以及 T17 / T18 正式验收；当前没有验收生产部署或真实金融服务。
